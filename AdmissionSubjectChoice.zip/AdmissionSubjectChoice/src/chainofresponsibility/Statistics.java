package chainofresponsibility;

public class Statistics implements Test {
	private Test nextsubject;

	@Override
	public void setNext(Test nextsubject) {
		// TODO Auto-generated method stub
		this.nextsubject = nextsubject;
	}

	@Override
	public void ServiceSupport(Student student) {
		// TODO Auto-generated method stub
		
			System.out.println("Statistics");
		
	}
}
