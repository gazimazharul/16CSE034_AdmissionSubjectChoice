package chainofresponsibility;

import java.util.Hashtable;

public class Student {
	
	Hashtable<String, Integer> marks = new Hashtable<String, Integer>();
	
	Integer phy=6, chem=5, math=10, bio=6, bang=4, eng=5;
	
	Student(){
		marks.put("Physics",phy);
		marks.put("Chemistry",chem);
		marks.put("Mathematics",math);
		marks.put("Biology",bio);
		
	}

}
