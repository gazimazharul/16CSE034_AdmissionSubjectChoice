package chainofresponsibility;

public interface Test {
	public  void setNext(Test nextsubject);
	public void ServiceSupport(Student student);
}
