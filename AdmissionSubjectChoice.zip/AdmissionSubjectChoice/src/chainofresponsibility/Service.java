package chainofresponsibility;

import java.util.Hashtable;

public class Service {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test cse = new CSE();
		Test math = new Math();
		Test botany = new Botany();
		Test chemistry = new Chemistry();
		Test geologyandmining = new GeologyAndMining();
		Test physics = new Physics();
		Test statistics = new Statistics();
		cse.setNext(math);
		math.setNext(botany);
		botany.setNext(chemistry);
		chemistry.setNext(geologyandmining);
		geologyandmining.setNext(physics);
		physics.setNext(statistics);		
		Student student = new Student();
		System.out.println(" --------------------------- Student Choose --------------------------\n");
		chemistry.ServiceSupport(student);
		System.out.println("\n");
		System.out.println("----------- More Subjects available ----------");
	}

	

}

